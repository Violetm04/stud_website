"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Scholarship, Application, WorkStudyProgram, WorkStudyApplication } from "./types"

export interface Announcement {
  id: string
  title: string
  content: string
  applicationPeriod: string
  requirement1: string
  requirement2: string
  createdAt: string
}

export interface AdminUser {
  id: string
  firstName: string
  lastName: string
  email: string
  username: string
  role: "admin"
  avatar?: string
}

interface AdminState {
  // Auth
  adminUser: AdminUser | null
  isAdminAuthenticated: boolean

  // Data
  announcements: Announcement[]
  scholarships: Scholarship[]
  applications: Application[]
  workStudyPrograms: WorkStudyProgram[] // Added for Work-Study
  workStudyApplications: WorkStudyApplication[] // Added for Work-Study

  // Actions
  adminLogin: (email: string, password: string) => Promise<boolean>
  adminLogout: () => void

  // Announcement actions
  getAnnouncements: () => Announcement[]
  createAnnouncement: (announcement: Omit<Announcement, "id" | "createdAt">) => void
  updateAnnouncement: (id: string, announcement: Partial<Announcement>) => void
  deleteAnnouncement: (id: string) => void

  // Scholarship actions
  getScholarships: () => Scholarship[]
  createScholarship: (scholarship: Omit<Scholarship, "id">) => void
  updateScholarship: (id: string, scholarship: Partial<Scholarship>) => void
  deleteScholarship: (id: string) => void
  getScholarship: (id: string) => Scholarship | undefined

  // Application actions
  getApplications: () => Application[]
  getApplication: (id: string) => Application | undefined
  updateApplicationStatus: (id: string, status: Application["status"]) => void

  // Work-Study actions (Admin side)
  getWorkStudyPrograms: () => WorkStudyProgram[]
  getWorkStudyProgram: (id: string) => WorkStudyProgram | undefined
  createWorkStudyProgram: (program: Omit<WorkStudyProgram, "id">) => void
  updateWorkStudyProgram: (id: string, program: Partial<WorkStudyProgram>) => void
  deleteWorkStudyProgram: (id: string) => void
  getWorkStudyApplications: () => WorkStudyApplication[]
  getWorkStudyApplication: (id: string) => WorkStudyApplication | undefined
  updateWorkStudyApplicationStatus: (id: string, status: WorkStudyApplication["status"]) => void
}

// Mock data
const mockAnnouncements: Announcement[] = [
  {
    id: "1",
    title: "New Scholarship Available",
    content: "Merit-based scholarship for Computer Science students is now open for applications.",
    applicationPeriod: "Jan 1 - Mar 31, 2024",
    requirement1: "GPA 3.5+ required",
    requirement2: "Full-time enrollment status",
    createdAt: "2024-01-01",
  },
  {
    id: "2",
    title: "Application Reminder",
    content: "Don't forget to submit your documents before the deadline.",
    applicationPeriod: "Feb 1 - Feb 15, 2024",
    requirement1: "All documents must be submitted",
    requirement2: "Late submissions not accepted",
    createdAt: "2024-01-15",
  },
]

const mockScholarships: Scholarship[] = [
  {
    id: "1",
    name: "Merit Excellence Scholarship",
    type: "Merit-based",
    eligibility: "Undergraduate students with GPA 3.5+",
    academicYear: "2024-2025",
    criteria: [
      "Minimum GPA of 3.5",
      "Full-time enrollment status",
      "Demonstrated academic excellence",
      "Financial need consideration",
    ],
    description:
      "The Merit Excellence Scholarship recognizes outstanding academic achievement and provides financial support to deserving students.",
    documents: [
      "Official transcripts",
      "Personal statement (500 words)",
      "Two letters of recommendation",
      "Financial aid documents",
      "Resume or CV",
    ],
    deadline: "March 15, 2024",
    publishedDate: "January 1, 2024",
    amount: "R 95,000",
  },
  {
    id: "2",
    name: "STEM Innovation Grant",
    type: "Field-specific",
    eligibility: "Computer Science & Engineering majors",
    academicYear: "2024-2025",
    criteria: [
      "Enrolled in STEM program",
      "Minimum GPA of 3.0",
      "Demonstrated innovation in technology",
      "Leadership experience preferred",
    ],
    description:
      "Supporting the next generation of STEM innovators through financial assistance and mentorship opportunities.",
    documents: [
      "Official transcripts",
      "Portfolio of projects",
      "Letter of recommendation from faculty",
      "Personal statement",
    ],
    deadline: "April 30, 2024",
    publishedDate: "February 1, 2024",
    amount: "R 142,500",
  },
]

const mockApplications: Application[] = [
  {
    id: "APP001",
    scholarshipId: "1",
    scholarshipName: "Merit Excellence Scholarship",
    userId: "1",
    fullName: "John Doe",
    surname: "Doe",
    dateOfBirth: "1995-05-15",
    address: "123 Main St, City, State 12345",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    studentId: "STU001",
    school: "State University",
    course: "Computer Science",
    yearLevel: "junior",
    submissionInstructions:
      "I am passionate about computer science and believe this scholarship will help me achieve my goals in software development.",
    status: "under-review",
    dateApplied: "2024-01-15",
  },
  {
    id: "APP002",
    scholarshipId: "2",
    scholarshipName: "STEM Innovation Grant",
    userId: "2",
    fullName: "Jane Smith",
    surname: "Smith",
    dateOfBirth: "1996-08-22",
    address: "456 Oak Ave, City, State 12345",
    email: "jane.smith@example.com",
    phone: "+1 (555) 987-6543",
    studentId: "STU002",
    school: "Tech Institute",
    course: "Engineering",
    yearLevel: "senior",
    submissionInstructions:
      "I have developed several innovative projects and would like to continue my research in renewable energy systems.",
    status: "pending",
    dateApplied: "2024-01-10",
  },
  {
    id: "APP003",
    scholarshipId: "1",
    scholarshipName: "Merit Excellence Scholarship",
    userId: "3",
    fullName: "Michael Johnson",
    surname: "Johnson",
    dateOfBirth: "1997-03-10",
    address: "789 Pine St, City, State 12345",
    email: "michael.johnson@example.com",
    phone: "+1 (555) 456-7890",
    studentId: "STU003",
    school: "Community College",
    course: "Business Administration",
    yearLevel: "sophomore",
    submissionInstructions:
      "I am dedicated to my studies and plan to transfer to a four-year university to complete my business degree.",
    status: "approved",
    dateApplied: "2024-01-05",
  },
]

// Mock Work-Study Data (Admin side)
const mockWorkStudyPrograms: WorkStudyProgram[] = [
  {
    id: "WS001",
    title: "Library Assistant",
    department: "University Library",
    description: "Assist librarians with shelving, cataloging, and student support.",
    hoursPerWeek: 10,
    payRate: "R 228/hour",
    slotsAvailable: 3,
    applicationDeadline: "April 1, 2025",
    publishedDate: "March 1, 2025",
  },
  {
    id: "WS002",
    title: "IT Help Desk Support",
    department: "Information Technology",
    description: "Provide technical support to students and faculty, troubleshoot common IT issues.",
    hoursPerWeek: 15,
    payRate: "Tuition Credit (R 3,800/month)",
    slotsAvailable: 2,
    applicationDeadline: "April 15, 2025",
    publishedDate: "March 10, 2025",
  },
  {
    id: "WS003",
    title: "Research Assistant (Biology)",
    department: "Biology Department",
    description: "Assist professors with lab experiments, data collection, and research documentation.",
    hoursPerWeek: 8,
    payRate: "R 342/hour",
    slotsAvailable: 1,
    applicationDeadline: "May 1, 2025",
    publishedDate: "March 20, 2025",
  },
]

const mockWorkStudyApplications: WorkStudyApplication[] = [
  {
    id: "WSA001",
    programId: "WS001",
    programTitle: "Library Assistant",
    userId: "user1",
    fullName: "John Doe",
    studentId: "STU001",
    status: "pending",
    dateApplied: "2025-03-25",
  },
  {
    id: "WSA002",
    programId: "WS002",
    programTitle: "IT Help Desk Support",
    userId: "user2",
    fullName: "Jane Smith",
    studentId: "STU002",
    status: "approved",
    dateApplied: "2025-03-20",
  },
]

export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      // Initial state
      adminUser: null,
      isAdminAuthenticated: false,
      announcements: mockAnnouncements,
      scholarships: mockScholarships,
      applications: mockApplications,
      workStudyPrograms: mockWorkStudyPrograms, // Initialize with mock data
      workStudyApplications: mockWorkStudyApplications, // Initialize with mock data

      // Auth actions
      adminLogin: async (email: string, password: string) => {
        // Mock admin login
        if (email === "admin@scholarhub.com" && password === "admin123") {
          const mockAdmin: AdminUser = {
            id: "admin1",
            firstName: "Admin",
            lastName: "User",
            email: email,
            username: "admin",
            role: "admin",
          }
          set({ adminUser: mockAdmin, isAdminAuthenticated: true })
          return true
        }
        return false
      },

      adminLogout: () => {
        set({ adminUser: null, isAdminAuthenticated: false })
        // Clear localStorage/sessionStorage if needed
        if (typeof window !== "undefined") {
          localStorage.removeItem("admin-storage")
        }
      },

      // Announcement actions
      getAnnouncements: () => get().announcements,

      createAnnouncement: (announcementData) => {
        const newAnnouncement: Announcement = {
          ...announcementData,
          id: Date.now().toString(),
          createdAt: new Date().toISOString().split("T")[0],
        }
        set((state) => ({
          announcements: [newAnnouncement, ...state.announcements],
        }))
      },

      updateAnnouncement: (id, announcementData) => {
        set((state) => ({
          announcements: state.announcements.map((a) => (a.id === id ? { ...a, ...announcementData } : a)),
        }))
      },

      deleteAnnouncement: (id) => {
        set((state) => ({
          announcements: state.announcements.filter((a) => a.id !== id),
        }))
      },

      // Scholarship actions
      getScholarships: () => get().scholarships,

      createScholarship: (scholarshipData) => {
        const newScholarship: Scholarship = {
          ...scholarshipData,
          id: Date.now().toString(),
        }
        set((state) => ({
          scholarships: [newScholarship, ...state.scholarships],
        }))
      },

      updateScholarship: (id, scholarshipData) => {
        set((state) => ({
          scholarships: state.scholarships.map((s) => (s.id === id ? { ...s, ...scholarshipData } : s)),
        }))
      },

      deleteScholarship: (id) => {
        set((state) => ({
          scholarships: state.scholarships.filter((s) => s.id !== id),
        }))
      },

      getScholarship: (id) => {
        return get().scholarships.find((s) => s.id === id)
      },

      // Application actions
      getApplications: () => get().applications,

      getApplication: (id) => {
        return get().applications.find((a) => a.id === id)
      },

      updateApplicationStatus: (id, status) => {
        set((state) => ({
          applications: state.applications.map((a) => (a.id === id ? { ...a, status } : a)),
        }))
      },

      // Work-Study actions (Admin side)
      getWorkStudyPrograms: () => get().workStudyPrograms,

      getWorkStudyProgram: (id: string) => {
        return get().workStudyPrograms.find((p) => p.id === id)
      },

      createWorkStudyProgram: (programData) => {
        const newProgram: WorkStudyProgram = {
          ...programData,
          id: Date.now().toString(),
        }
        set((state) => ({
          workStudyPrograms: [newProgram, ...state.workStudyPrograms],
        }))
      },

      updateWorkStudyProgram: (id, programData) => {
        set((state) => ({
          workStudyPrograms: state.workStudyPrograms.map((p) => (p.id === id ? { ...p, ...programData } : p)),
        }))
      },

      deleteWorkStudyProgram: (id) => {
        set((state) => ({
          workStudyPrograms: state.workStudyPrograms.filter((p) => p.id !== id),
        }))
      },

      getWorkStudyApplications: () => get().workStudyApplications,

      getWorkStudyApplication: (id) => {
        return get().workStudyApplications.find((a) => a.id === id)
      },

      updateWorkStudyApplicationStatus: (id, status) => {
        set((state) => ({
          workStudyApplications: state.workStudyApplications.map((a) => (a.id === id ? { ...a, status } : a)),
        }))
      },
    }),
    {
      name: "admin-storage",
    },
  ),
)
