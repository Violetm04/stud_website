"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { User, Scholarship, Application, Notification } from "./types"

interface AppState {
  // Auth
  user: User | null
  isAuthenticated: boolean

  // Data
  scholarships: Scholarship[]
  applications: Application[]
  notifications: Notification[]

  // Actions
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>
  logout: () => void
  updateUser: (userData: Partial<User>) => void

  // Scholarship actions
  getScholarships: () => Scholarship[]
  getScholarship: (id: string) => Scholarship | undefined

  // Application actions
  submitApplication: (applicationData: Omit<Application, "id" | "dateApplied" | "status">) => void
  getApplications: () => Application[]

  // Notification actions
  getNotifications: () => Notification[]
  markNotificationAsRead: (id: string) => void
  addNotification: (notification: Omit<Notification, "id">) => void
}

// Mock data
const mockScholarships: Scholarship[] = [
  {
    id: "1",
    name: "Merit Excellence Scholarship",
    type: "Merit-based",
    eligibility: "Undergraduate students with GPA 3.5+",
    academicYear: "2024-2025",
    criteria: [
      "Minimum GPA of 3.5",
      "Full-time enrollment status",
      "Demonstrated academic excellence",
      "Financial need consideration",
    ],
    description:
      "The Merit Excellence Scholarship recognizes outstanding academic achievement and provides financial support to deserving students. This scholarship aims to reduce financial barriers and enable students to focus on their academic pursuits.",
    documents: [
      "Official transcripts",
      "Personal statement (500 words)",
      "Two letters of recommendation",
      "Financial aid documents",
      "Resume or CV",
    ],
    deadline: "March 15, 2024",
    publishedDate: "January 1, 2024",
    amount: "R 95,000",
  },
  {
    id: "2",
    name: "STEM Innovation Grant",
    type: "Field-specific",
    eligibility: "Computer Science & Engineering majors",
    academicYear: "2024-2025",
    criteria: [
      "Enrolled in STEM program",
      "Minimum GPA of 3.0",
      "Demonstrated innovation in technology",
      "Leadership experience preferred",
    ],
    description:
      "Supporting the next generation of STEM innovators through financial assistance and mentorship opportunities.",
    documents: [
      "Official transcripts",
      "Portfolio of projects",
      "Letter of recommendation from faculty",
      "Personal statement",
    ],
    deadline: "April 30, 2024",
    publishedDate: "February 1, 2024",
    amount: "R 142,500",
  },
  {
    id: "3",
    name: "Community Leadership Award",
    type: "Leadership",
    eligibility: "Students with community service experience",
    academicYear: "2024-2025",
    criteria: [
      "Minimum 100 hours of community service",
      "Leadership role in community organization",
      "Academic standing in good standing",
      "Commitment to continued service",
    ],
    description:
      "Recognizing students who have made significant contributions to their communities through volunteer work and leadership.",
    documents: [
      "Community service verification",
      "Letters of recommendation",
      "Personal essay on community impact",
      "Academic transcripts",
    ],
    deadline: "May 20, 2024",
    publishedDate: "January 15, 2024",
    amount: "$3,000",
  },
]

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "success",
    title: "Application Approved",
    message: "Your application for STEM Innovation Grant has been approved!",
    time: "2 hours ago",
    read: false,
  },
  {
    id: "2",
    type: "warning",
    title: "Deadline Reminder",
    message: "Merit Excellence Scholarship application deadline is in 3 days",
    time: "1 day ago",
    read: false,
  },
  {
    id: "3",
    type: "info",
    title: "New Scholarship Available",
    message: "Community Leadership Award is now accepting applications",
    time: "3 days ago",
    read: true,
  },
]

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      isAuthenticated: false,
      scholarships: mockScholarships,
      applications: [],
      notifications: mockNotifications,

      // Auth actions
      login: async (email: string, password: string) => {
        // Mock login - in real app, this would call an API
        if (email && password) {
          const mockUser: User = {
            id: "1",
            firstName: "John",
            lastName: "Doe",
            email: email,
            username: "johndoe",
            studentId: "STU001",
            school: "State University",
            course: "Computer Science",
            yearLevel: "Junior",
          }
          set({ user: mockUser, isAuthenticated: true })
          return true
        }
        return false
      },

      register: async (userData) => {
        // Mock registration
        const newUser: User = {
          id: Date.now().toString(),
          firstName: userData.firstName || "",
          lastName: userData.lastName || "",
          email: userData.email || "",
          username: userData.email?.split("@")[0] || "",
        }
        set({ user: newUser, isAuthenticated: true })
        return true
      },

      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      updateUser: (userData) => {
        const currentUser = get().user
        if (currentUser) {
          set({ user: { ...currentUser, ...userData } })
        }
      },

      // Scholarship actions
      getScholarships: () => get().scholarships,

      getScholarship: (id: string) => {
        return get().scholarships.find((s) => s.id === id)
      },

      // Application actions
      submitApplication: (applicationData) => {
        const newApplication: Application = {
          ...applicationData,
          id: Date.now().toString(),
          dateApplied: new Date().toISOString().split("T")[0],
          status: "pending",
        }

        set((state) => ({
          applications: [...state.applications, newApplication],
          notifications: [
            {
              id: Date.now().toString(),
              type: "success",
              title: "Application Submitted",
              message: `Your application for ${applicationData.scholarshipName} has been submitted successfully!`,
              time: "Just now",
              read: false,
            },
            ...state.notifications,
          ],
        }))
      },

      getApplications: () => get().applications,

      // Notification actions
      getNotifications: () => get().notifications,

      markNotificationAsRead: (id: string) => {
        set((state) => ({
          notifications: state.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
        }))
      },

      addNotification: (notification) => {
        const newNotification = {
          ...notification,
          id: Date.now().toString(),
        }
        set((state) => ({
          notifications: [newNotification, ...state.notifications],
        }))
      },
    }),
    {
      name: "scholarship-app-storage",
    },
  ),
)
