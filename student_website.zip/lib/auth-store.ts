"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { User, Scholarship, Application, Notification, WorkStudyProgram, WorkStudyApplication } from "./types"

export interface AdminUser {
  id: string
  firstName: string
  lastName: string
  email: string
  username: string
  role: "admin"
  avatar?: string
}

export type AuthUser = User | AdminUser

interface AuthState {
  // Auth
  currentUser: AuthUser | null
  isAuthenticated: boolean
  userType: "user" | "admin" | null

  // Data
  scholarships: Scholarship[]
  applications: Application[]
  notifications: Notification[]
  workStudyPrograms: WorkStudyProgram[] // Added for Work-Study
  workStudyApplications: WorkStudyApplication[] // Added for Work-Study

  // Actions
  login: (email: string, password: string) => Promise<{ success: boolean; userType?: "user" | "admin" }>
  register: (userData: Partial<User> & { password: string; role?: "admin" }) => Promise<boolean>
  logout: () => void
  updateUser: (userData: Partial<User>) => void

  // Scholarship actions
  getScholarships: () => Scholarship[]
  getScholarship: (id: string) => Scholarship | undefined
  createScholarship: (scholarship: Omit<Scholarship, "id">) => void
  updateScholarship: (id: string, scholarship: Partial<Scholarship>) => void
  deleteScholarship: (id: string) => void

  // Application actions
  submitApplication: (applicationData: Omit<Application, "id" | "dateApplied" | "status">) => void
  getApplications: () => Application[]
  getApplication: (id: string) => Application | undefined
  updateApplicationStatus: (id: string, status: Application["status"]) => void

  // Notification actions
  getNotifications: () => Notification[]
  markNotificationAsRead: (id: string) => void
  addNotification: (notification: Omit<Notification, "id">) => void

  // Work-Study actions (Student side)
  getWorkStudyPrograms: () => WorkStudyProgram[]
  getWorkStudyProgram: (id: string) => WorkStudyProgram | undefined
  applyForWorkStudy: (applicationData: Omit<WorkStudyApplication, "id" | "dateApplied" | "status">) => void
  getWorkStudyApplications: () => WorkStudyApplication[]
}

// Mock data
const mockScholarships: Scholarship[] = [
  {
    id: "1",
    name: "Merit Excellence Scholarship",
    type: "Merit-based",
    eligibility: "Undergraduate students with GPA 3.5+",
    academicYear: "2024-2025",
    criteria: [
      "Minimum GPA of 3.5",
      "Full-time enrollment status",
      "Demonstrated academic excellence",
      "Financial need consideration",
    ],
    description:
      "The Merit Excellence Scholarship recognizes outstanding academic achievement and provides financial support to deserving students.",
    documents: [
      "Official transcripts",
      "Personal statement (500 words)",
      "Two letters of recommendation",
      "Financial aid documents",
      "Resume or CV",
    ],
    deadline: "March 15, 2024",
    publishedDate: "January 1, 2024",
    amount: "$5,000",
  },
  {
    id: "2",
    name: "STEM Innovation Grant",
    type: "Field-specific",
    eligibility: "Computer Science & Engineering majors",
    academicYear: "2024-2025",
    criteria: [
      "Enrolled in STEM program",
      "Minimum GPA of 3.0",
      "Demonstrated innovation in technology",
      "Leadership experience preferred",
    ],
    description:
      "Supporting the next generation of STEM innovators through financial assistance and mentorship opportunities.",
    documents: [
      "Official transcripts",
      "Portfolio of projects",
      "Letter of recommendation from faculty",
      "Personal statement",
    ],
    deadline: "April 30, 2024",
    publishedDate: "February 1, 2024",
    amount: "$7,500",
  },
]

const mockApplications: Application[] = [
  {
    id: "APP001",
    scholarshipId: "1",
    scholarshipName: "Merit Excellence Scholarship",
    userId: "1",
    fullName: "John Doe",
    surname: "Doe",
    dateOfBirth: "1995-05-15",
    address: "123 Main St, City, State 12345",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    studentId: "STU001",
    school: "State University",
    course: "Computer Science",
    yearLevel: "junior",
    submissionInstructions:
      "I am passionate about computer science and believe this scholarship will help me achieve my goals.",
    status: "under-review",
    dateApplied: "2024-01-15",
  },
]

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "success",
    title: "Application Approved",
    message: "Your application for STEM Innovation Grant has been approved!",
    time: "2 hours ago",
    read: false,
  },
  {
    id: "2",
    type: "warning",
    title: "Deadline Reminder",
    message: "Merit Excellence Scholarship application deadline is in 3 days",
    time: "1 day ago",
    read: false,
  },
]

// Mock Work-Study Data
const mockWorkStudyPrograms: WorkStudyProgram[] = [
  {
    id: "WS001",
    title: "Library Assistant",
    department: "University Library",
    description: "Assist librarians with shelving, cataloging, and student support.",
    hoursPerWeek: 10,
    payRate: "$12/hour",
    slotsAvailable: 3,
    applicationDeadline: "April 1, 2025",
    publishedDate: "March 1, 2025",
  },
  {
    id: "WS002",
    title: "IT Help Desk Support",
    department: "Information Technology",
    description: "Provide technical support to students and faculty, troubleshoot common IT issues.",
    hoursPerWeek: 15,
    payRate: "Tuition Credit ($200/month)",
    slotsAvailable: 2,
    applicationDeadline: "April 15, 2025",
    publishedDate: "March 10, 2025",
  },
  {
    id: "WS003",
    title: "Research Assistant (Biology)",
    department: "Biology Department",
    description: "Assist professors with lab experiments, data collection, and research documentation.",
    hoursPerWeek: 8,
    payRate: "$18/hour",
    slotsAvailable: 1,
    applicationDeadline: "May 1, 2025",
    publishedDate: "March 20, 2025",
  },
]

const mockWorkStudyApplications: WorkStudyApplication[] = [
  {
    id: "WSA001",
    programId: "WS001",
    programTitle: "Library Assistant",
    userId: "user1",
    fullName: "John Doe",
    studentId: "STU001",
    status: "pending",
    dateApplied: "2025-03-25",
  },
]

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentUser: null,
      isAuthenticated: false,
      userType: null,
      scholarships: mockScholarships,
      applications: mockApplications,
      notifications: mockNotifications,
      workStudyPrograms: mockWorkStudyPrograms, // Initialize with mock data
      workStudyApplications: mockWorkStudyApplications, // Initialize with mock data

      // Auth actions
      login: async (email: string, password: string) => {
        // Check if admin
        if (email === "admin@scholarhub.com" && password === "admin123") {
          const adminUser: AdminUser = {
            id: "admin1",
            firstName: "Admin",
            lastName: "User",
            email: email,
            username: "admin",
            role: "admin",
          }
          set({
            currentUser: adminUser,
            isAuthenticated: true,
            userType: "admin",
          })
          return { success: true, userType: "admin" }
        }

        // Check regular user (any email/password combo for demo)
        if (email && password) {
          const regularUser: User = {
            id: "user1",
            firstName: "John",
            lastName: "Doe",
            email: email,
            username: email.split("@")[0],
            studentId: "STU001",
            school: "State University",
            course: "Computer Science",
            yearLevel: "Junior",
            phone: "+1 (555) 123-4567",
            address: "123 Main St, City, State 12345",
            dateOfBirth: "1995-05-15",
          }
          set({
            currentUser: regularUser,
            isAuthenticated: true,
            userType: "user",
          })
          return { success: true, userType: "user" }
        }

        return { success: false }
      },

      register: async (userData) => {
        // Check if admin registration
        if (userData.role === "admin") {
          const newAdmin: AdminUser = {
            id: Date.now().toString(),
            firstName: userData.firstName || "",
            lastName: userData.lastName || "",
            email: userData.email || "",
            username: userData.email?.split("@")[0] || "",
            role: "admin",
          }
          set({
            currentUser: newAdmin,
            isAuthenticated: true,
            userType: "admin",
          })
          return true
        }

        // Mock registration - creates regular user
        const newUser: User = {
          id: Date.now().toString(),
          firstName: userData.firstName || "",
          lastName: userData.lastName || "",
          email: userData.email || "",
          username: userData.email?.split("@")[0] || "",
          studentId: "",
          school: "",
          course: "",
          yearLevel: "",
          phone: "",
          address: "",
          dateOfBirth: "",
        }
        set({
          currentUser: newUser,
          isAuthenticated: true,
          userType: "user",
        })
        return true
      },

      logout: () => {
        set({
          currentUser: null,
          isAuthenticated: false,
          userType: null,
        })
        // Clear localStorage/sessionStorage if needed
        if (typeof window !== "undefined") {
          localStorage.removeItem("auth-storage")
        }
      },

      updateUser: (userData) => {
        const currentUser = get().currentUser
        if (currentUser && currentUser.role !== "admin") {
          set({ currentUser: { ...currentUser, ...userData } })
        }
      },

      // Scholarship actions
      getScholarships: () => get().scholarships,

      getScholarship: (id: string) => {
        return get().scholarships.find((s) => s.id === id)
      },

      createScholarship: (scholarshipData) => {
        const newScholarship: Scholarship = {
          ...scholarshipData,
          id: Date.now().toString(),
        }
        set((state) => ({
          scholarships: [newScholarship, ...state.scholarships],
        }))
      },

      updateScholarship: (id, scholarshipData) => {
        set((state) => ({
          scholarships: state.scholarships.map((s) => (s.id === id ? { ...s, ...scholarshipData } : s)),
        }))
      },

      deleteScholarship: (id) => {
        set((state) => ({
          scholarships: state.scholarships.filter((s) => s.id !== id),
        }))
      },

      // Application actions
      submitApplication: (applicationData) => {
        const newApplication: Application = {
          ...applicationData,
          id: Date.now().toString(),
          dateApplied: new Date().toISOString().split("T")[0],
          status: "pending",
        }

        set((state) => ({
          applications: [...state.applications, newApplication],
          notifications: [
            {
              id: Date.now().toString(),
              type: "success",
              title: "Application Submitted",
              message: `Your application for ${applicationData.scholarshipName} has been submitted successfully!`,
              time: "Just now",
              read: false,
            },
            ...state.notifications,
          ],
        }))
      },

      getApplications: () => get().applications,

      getApplication: (id) => {
        return get().applications.find((a) => a.id === id)
      },

      updateApplicationStatus: (id, status) => {
        set((state) => ({
          applications: state.applications.map((a) => (a.id === id ? { ...a, status } : a)),
        }))
      },

      // Notification actions
      getNotifications: () => get().notifications,

      markNotificationAsRead: (id: string) => {
        set((state) => ({
          notifications: state.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
        }))
      },

      addNotification: (notification) => {
        const newNotification = {
          ...notification,
          id: Date.now().toString(),
        }
        set((state) => ({
          notifications: [newNotification, ...state.notifications],
        }))
      },

      // Work-Study actions (Student side)
      getWorkStudyPrograms: () => get().workStudyPrograms,

      getWorkStudyProgram: (id: string) => {
        return get().workStudyPrograms.find((p) => p.id === id)
      },

      applyForWorkStudy: (applicationData) => {
        const newApplication: WorkStudyApplication = {
          ...applicationData,
          id: Date.now().toString(),
          dateApplied: new Date().toISOString().split("T")[0],
          status: "pending",
        }
        set((state) => ({
          workStudyApplications: [...state.workStudyApplications, newApplication],
          notifications: [
            {
              id: Date.now().toString(),
              type: "success",
              title: "Work-Study Application Submitted",
              message: `Your application for ${applicationData.programTitle} has been submitted successfully!`,
              time: "Just now",
              read: false,
            },
            ...state.notifications,
          ],
        }))
      },

      getWorkStudyApplications: () => get().workStudyApplications,
    }),
    {
      name: "auth-storage",
    },
  ),
)
