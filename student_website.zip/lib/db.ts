import { neon } from "@neondatabase/serverless"

// Initialize the Neon client using the DATABASE_URL from your .env.local file.
// The '!' tells TypeScript that we are sure this environment variable will be defined.
const sql = neon(process.env.DATABASE_URL!)

export { sql }
