export interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  username: string
  avatar?: string
  studentId?: string
  school?: string
  course?: string
  yearLevel?: string
  phone?: string
  address?: string
  dateOfBirth?: string
}

export interface Scholarship {
  id: string
  name: string
  type: string
  eligibility: string
  academicYear: string
  criteria: string[]
  description: string
  documents: string[]
  deadline: string
  publishedDate: string
  amount: string
}

export interface Application {
  id: string
  scholarshipId: string
  scholarshipName: string
  userId: string
  fullName: string
  surname: string
  dateOfBirth: string
  address: string
  email: string
  phone: string
  studentId: string
  school: string
  course: string
  yearLevel: string
  submissionInstructions: string
  status: "pending" | "under-review" | "approved" | "rejected"
  dateApplied: string
}

export interface Notification {
  id: string
  type: "success" | "warning" | "info" | "error"
  title: string
  message: string
  time: string
  read: boolean
}

export interface WorkStudyProgram {
  id: string
  title: string
  department: string
  description: string
  hoursPerWeek: number
  payRate: string // e.g., "$15/hour" or "Tuition Credit"
  slotsAvailable: number
  applicationDeadline: string
  publishedDate: string
}

export interface WorkStudyApplication {
  id: string
  programId: string
  programTitle: string
  userId: string
  fullName: string
  studentId: string
  status: "pending" | "approved" | "rejected" | "completed"
  dateApplied: string
  // Potentially add more fields like 'hoursWorked', 'creditsEarned' later
}
