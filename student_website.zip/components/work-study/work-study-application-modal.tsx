"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useAdminStore, type WorkStudyApplication } from "@/lib/admin-store"
import { Mail, Phone, GraduationCap } from "lucide-react"

interface WorkStudyApplicationModalProps {
  isOpen: boolean
  onClose: () => void
  application: WorkStudyApplication | null
}

function getStatusBadge(status: string) {
  switch (status) {
    case "approved":
      return <Badge className="bg-green-100 text-green-800">Approved</Badge>
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>
    case "pending":
      return <Badge variant="outline">Pending</Badge>
    case "completed":
      return <Badge variant="secondary">Completed</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export function WorkStudyApplicationModal({ isOpen, onClose, application }: WorkStudyApplicationModalProps) {
  const { updateWorkStudyApplicationStatus } = useAdminStore()
  const [currentStatus, setCurrentStatus] = useState<WorkStudyApplication["status"]>(application?.status || "pending")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (application) {
      setCurrentStatus(application.status)
    }
  }, [application])

  const handleStatusChange = (value: WorkStudyApplication["status"]) => {
    setCurrentStatus(value)
  }

  const handleSaveStatus = async () => {
    if (!application) return
    setIsLoading(true)
    try {
      updateWorkStudyApplicationStatus(application.id, currentStatus)
      onClose()
    } catch (error) {
      console.error("Failed to update application status:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!application) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Work-Study Application Details</DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6 py-4">
          {/* Application Info */}
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-gray-600">Program Title</p>
              <p className="text-base font-semibold">{application.programTitle}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Applicant Name</p>
              <p className="text-base">{application.fullName}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Student ID</p>
              <p className="text-base">{application.studentId}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Date Applied</p>
              <p className="text-base">{application.dateApplied}</p>
            </div>
          </div>

          {/* Personal Details (Mocked for now, would come from user profile) */}
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-gray-600">Email</p>
              <div className="flex items-center space-x-1">
                <Mail className="h-4 w-4 text-gray-400" />
                <p className="text-sm">john.doe@example.com</p> {/* Mocked */}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Phone</p>
              <div className="flex items-center space-x-1">
                <Phone className="h-4 w-4 text-gray-400" />
                <p className="text-sm">+1 (555) 123-4567</p> {/* Mocked */}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Current School</p>
              <div className="flex items-center space-x-1">
                <GraduationCap className="h-4 w-4 text-gray-400" />
                <p className="text-sm">State University</p> {/* Mocked */}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="status">Update Status</Label>
            <Select value={currentStatus} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex space-x-4 pt-4">
            <Button onClick={handleSaveStatus} disabled={isLoading}>
              {isLoading ? "Saving..." : "Save Status"}
            </Button>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
