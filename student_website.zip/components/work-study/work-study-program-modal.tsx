"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useAdminStore, type WorkStudyProgram } from "@/lib/admin-store"

interface WorkStudyProgramModalProps {
  isOpen: boolean
  onClose: () => void
  program: WorkStudyProgram | null
  mode: "create" | "edit"
}

export function WorkStudyProgramModal({ isOpen, onClose, program, mode }: WorkStudyProgramModalProps) {
  const { createWorkStudyProgram, updateWorkStudyProgram } = useAdminStore()
  const [formData, setFormData] = useState({
    title: "",
    department: "",
    description: "",
    hoursPerWeek: "",
    payRate: "",
    slotsAvailable: "",
    applicationDeadline: "",
    publishedDate: new Date().toISOString().split("T")[0],
  })
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (program && mode === "edit") {
      setFormData({
        title: program.title,
        department: program.department,
        description: program.description,
        hoursPerWeek: program.hoursPerWeek.toString(),
        payRate: program.payRate,
        slotsAvailable: program.slotsAvailable.toString(),
        applicationDeadline: program.applicationDeadline,
        publishedDate: program.publishedDate,
      })
    } else {
      setFormData({
        title: "",
        department: "",
        description: "",
        hoursPerWeek: "",
        payRate: "",
        slotsAvailable: "",
        applicationDeadline: "",
        publishedDate: new Date().toISOString().split("T")[0],
      })
    }
  }, [program, mode, isOpen])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const programData = {
        ...formData,
        hoursPerWeek: Number.parseInt(formData.hoursPerWeek),
        slotsAvailable: Number.parseInt(formData.slotsAvailable),
      } as Omit<WorkStudyProgram, "id">

      if (mode === "create") {
        createWorkStudyProgram(programData)
      } else if (mode === "edit" && program) {
        updateWorkStudyProgram(program.id, programData)
      }
      onClose()
    } catch (error) {
      console.error("Failed to save work-study program:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Create New Work-Study Program" : "Edit Work-Study Program"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Program Title</Label>
            <Input
              id="title"
              placeholder="e.g., Library Assistant"
              value={formData.title}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Input
                id="department"
                placeholder="e.g., University Library"
                value={formData.department}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="payRate">Pay Rate</Label>
              <Input
                id="payRate"
                placeholder="e.g., $15/hour or Tuition Credit"
                value={formData.payRate}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Provide a detailed description of the role and responsibilities."
              value={formData.description}
              onChange={handleInputChange}
              className="min-h-[100px]"
              required
            />
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="hoursPerWeek">Hours Per Week</Label>
              <Input
                id="hoursPerWeek"
                type="number"
                placeholder="e.g., 10"
                value={formData.hoursPerWeek}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slotsAvailable">Slots Available</Label>
              <Input
                id="slotsAvailable"
                type="number"
                placeholder="e.g., 5"
                value={formData.slotsAvailable}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="applicationDeadline">Application Deadline</Label>
              <Input
                id="applicationDeadline"
                type="date"
                value={formData.applicationDeadline}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>

          <div className="flex space-x-4 pt-6">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
