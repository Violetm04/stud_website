"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuthStore } from "@/lib/auth-store"

interface AuthGuardProps {
  children: React.ReactNode
  requiredRole?: "user" | "admin"
}

export function UnifiedAuthGuard({ children, requiredRole }: AuthGuardProps) {
  const { isAuthenticated, userType } = useAuthStore()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/") // Changed from "/auth/signin" to "/"
      return
    }

    if (requiredRole && userType !== requiredRole) {
      // Redirect to appropriate dashboard based on user type
      if (userType === "admin") {
        router.push("/admin/dashboard")
      } else {
        router.push("/dashboard")
      }
    }
  }, [isAuthenticated, userType, requiredRole, router])

  if (!isAuthenticated) {
    return null
  }

  if (requiredRole && userType !== requiredRole) {
    return null
  }

  return <>{children}</>
}
