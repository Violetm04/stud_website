"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAdminStore } from "@/lib/admin-store"

export function AdminAuthGuard({ children }: { children: React.ReactNode }) {
  const { isAdminAuthenticated } = useAdminStore()
  const router = useRouter()

  useEffect(() => {
    if (!isAdminAuthenticated) {
      router.push("/") // Changed from "/admin/login" to "/"
    }
  }, [isAdminAuthenticated, router])

  if (!isAdminAuthenticated) {
    return null
  }

  return <>{children}</>
}
