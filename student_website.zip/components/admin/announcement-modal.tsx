"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useAdminStore, type Announcement } from "@/lib/admin-store"

interface AnnouncementModalProps {
  isOpen: boolean
  onClose: () => void
  announcement: Announcement | null
  mode: "create" | "edit"
}

export function AnnouncementModal({ isOpen, onClose, announcement, mode }: AnnouncementModalProps) {
  const { createAnnouncement, updateAnnouncement } = useAdminStore()
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    applicationPeriod: "",
    requirement1: "",
    requirement2: "",
  })
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (announcement && mode === "edit") {
      setFormData({
        title: announcement.title,
        content: announcement.content,
        applicationPeriod: announcement.applicationPeriod,
        requirement1: announcement.requirement1,
        requirement2: announcement.requirement2,
      })
    } else {
      setFormData({
        title: "",
        content: "",
        applicationPeriod: "",
        requirement1: "",
        requirement2: "",
      })
    }
  }, [announcement, mode, isOpen])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (mode === "create") {
        createAnnouncement(formData)
      } else if (mode === "edit" && announcement) {
        updateAnnouncement(announcement.id, formData)
      }
      onClose()
    } catch (error) {
      console.error("Failed to save announcement:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Create New Announcement" : "Edit Announcement"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="Enter announcement title"
              value={formData.title}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Content</Label>
            <Textarea
              id="content"
              placeholder="Enter announcement content"
              value={formData.content}
              onChange={handleInputChange}
              className="min-h-[100px]"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="applicationPeriod">Application Period</Label>
            <Input
              id="applicationPeriod"
              placeholder="e.g., Jan 1 - Mar 31, 2024"
              value={formData.applicationPeriod}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="requirement1">Requirement 1</Label>
            <Input
              id="requirement1"
              placeholder="Enter first requirement"
              value={formData.requirement1}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="requirement2">Requirement 2</Label>
            <Input
              id="requirement2"
              placeholder="Enter second requirement"
              value={formData.requirement2}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="flex space-x-4 pt-6">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
