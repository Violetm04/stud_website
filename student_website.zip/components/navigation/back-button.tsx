"use client"

import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

interface BackButtonProps {
  fallbackUrl?: string
  label?: string
  variant?: "ghost" | "outline" | "default"
  size?: "sm" | "default" | "lg"
}

export function BackButton({ fallbackUrl = "/", label = "Back", variant = "ghost", size = "sm" }: BackButtonProps) {
  const router = useRouter()

  const handleBack = () => {
    // Check if there's browser history to go back to
    if (window.history.length > 1) {
      router.back()
    } else {
      // Fallback to a specific URL if no history
      router.push(fallbackUrl)
    }
  }

  return (
    <Button variant={variant} size={size} onClick={handleBack}>
      <ArrowLeft className="h-4 w-4 mr-2" />
      {label}
    </Button>
  )
}
