"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { GraduationCap, User, Shield } from "lucide-react"
import { useAuthStore } from "@/lib/auth-store"
import Link from "next/link"

// Import useAdminStore
import { useAdminStore } from "@/lib/admin-store"

export default function SignIn() {
  const [userFormData, setUserFormData] = useState({
    email: "",
    password: "",
  })
  const [adminFormData, setAdminFormData] = useState({
    email: "admin@scholarhub.com",
    password: "admin123",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const { login } = useAuthStore()
  const { adminLogin } = useAdminStore() // Add this line to import adminLogin
  const router = useRouter()

  const handleUserInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
    setError("")
  }

  const handleAdminInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAdminFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
    setError("")
  }

  const handleUserSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const result = await login(userFormData.email, userFormData.password)
      if (result.success) {
        if (result.userType === "admin") {
          router.push("/admin/dashboard")
        } else {
          router.push("/dashboard")
        }
      } else {
        setError("Invalid email or password")
      }
    } catch (error) {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Modify handleAdminSignIn function:
  const handleAdminSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Use adminLogin from useAdminStore for admin sign-in
      const success = await adminLogin(adminFormData.email, adminFormData.password)
      if (success) {
        router.push("/admin/dashboard")
      } else {
        setError("Invalid admin credentials")
      }
    } catch (error) {
      setError("Admin login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <GraduationCap className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">ScholarHub</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Welcome Back</h1>
            <p className="text-gray-600">Sign in to your account</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-center">Sign In</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="user" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="user" className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>Student</span>
                  </TabsTrigger>
                  <TabsTrigger value="admin" className="flex items-center space-x-2">
                    <Shield className="h-4 w-4" />
                    <span>Admin</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="user" className="space-y-4 mt-6">
                  <form onSubmit={handleUserSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={userFormData.email}
                        onChange={handleUserInputChange}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={userFormData.password}
                        onChange={handleUserInputChange}
                        required
                      />
                    </div>

                    {error && <div className="text-red-600 text-sm text-center">{error}</div>}

                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
                      {isLoading ? "Signing In..." : "Sign In as Student"}
                    </Button>
                  </form>

                  <div className="text-center text-sm text-gray-600">
                    Don't have an account?{" "}
                    <Link href="/auth/signup" className="text-blue-600 hover:underline">
                      Sign Up as Student
                    </Link>
                  </div>

                  <div className="text-center text-sm text-gray-600 mt-4 p-3 bg-blue-50 rounded">
                    <p className="font-medium text-blue-800">Student Account:</p>
                    <p className="text-blue-700">Use any email and password to create/login as a student</p>
                  </div>
                </TabsContent>

                <TabsContent value="admin" className="space-y-4 mt-6">
                  <form onSubmit={handleAdminSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Admin Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="admin@scholarhub.com"
                        value={adminFormData.email}
                        onChange={handleAdminInputChange}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password">Admin Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={adminFormData.password}
                        onChange={handleAdminInputChange}
                        required
                      />
                    </div>

                    {error && <div className="text-red-600 text-sm text-center">{error}</div>}

                    <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700" disabled={isLoading}>
                      {isLoading ? "Signing In..." : "Sign In as Admin"}
                    </Button>
                  </form>

                  <div className="text-center text-sm text-gray-600">
                    Need an admin account?{" "}
                    <Link href="/auth/admin-signup" className="text-purple-600 hover:underline">
                      Register as Admin
                    </Link>
                  </div>

                  <div className="text-center text-sm text-gray-600 mt-4 p-3 bg-gray-50 rounded">
                    <p className="font-medium">Demo Admin Credentials:</p>
                    <p>Email: admin@scholarhub.com</p>
                    <p>Password: admin123</p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
