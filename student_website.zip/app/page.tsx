"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { GraduationCap, User, Shield } from "lucide-react"
import { useAppStore } from "@/lib/store"
import Link from "next/link"

export default function LandingPage() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    accountType: "",
    adminCode: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const { register } = useAppStore()
  const router = useRouter()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
    setError("")
  }

  const handleAccountTypeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      accountType: value,
      adminCode: "", // Reset admin code when changing account type
    }))
    setError("")
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Validate required fields
    if (!formData.accountType) {
      setError("Please select an account type")
      setIsLoading(false)
      return
    }

    // Validate password confirmation
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match")
      setIsLoading(false)
      return
    }

    // Validate admin code if admin account
    if (formData.accountType === "admin" && formData.adminCode !== "ADMIN2024") {
      setError("Invalid admin code. Please contact system administrator.")
      setIsLoading(false)
      return
    }

    try {
      const userData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        password: formData.password,
        ...(formData.accountType === "admin" && { role: "admin" as const }),
      }

      const success = await register(userData)
      if (success) {
        if (formData.accountType === "admin") {
          router.push("/admin/dashboard")
        } else {
          router.push("/dashboard")
        }
      }
    } catch (error) {
      setError("Registration failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleLearnMore = () => {
    router.push("/learn-more")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-screen">
          {/* Left Side - Main Content */}
          <div className="space-y-8">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">Student Financial Assistance and Alternative Payment System</span>
            </div>

            <div className="space-y-6">
              <h1 className="text-5xl font-bold text-gray-900 leading-tight">
                Your Gateway to
                <span className="text-blue-600"> Educational Excellence</span>
              </h1>

              <p className="text-xl text-gray-600 leading-relaxed">
                Discover and apply for scholarships that match your academic goals. Our platform connects students with
                opportunities to fund their education and achieve their dreams.
              </p>

              <div className="flex space-x-4">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/auth/signin">Apply Now</Link>
                </Button>
                <Button variant="outline" size="lg" onClick={handleLearnMore}>
                  Learn More
                </Button>
              </div>

              <div className="text-center mt-4">
                <Link href="/help/account-types" className="text-sm text-blue-600 hover:underline">
                  Not sure which account type? Learn about Student vs Admin accounts
                </Link>
              </div>
            </div>
          </div>

          {/* Right Side - Sign Up Form */}
          <div className="flex justify-center lg:justify-end">
            <Card className="w-full max-w-md">
              <CardHeader>
                <CardTitle className="text-center">Create Account</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSignUp} className="space-y-4">
                  {/* Account Type Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="accountType">Account Type</Label>
                    <Select value={formData.accountType} onValueChange={handleAccountTypeChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select account type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="student">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-blue-600" />
                            <span>Student Account</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="admin">
                          <div className="flex items-center space-x-2">
                            <Shield className="h-4 w-4 text-purple-600" />
                            <span>Administrator Account</span>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Admin Code Field (only show for admin) */}
                  {formData.accountType === "admin" && (
                    <div className="space-y-2">
                      <Label htmlFor="adminCode">Admin Code</Label>
                      <Input
                        id="adminCode"
                        type="password"
                        placeholder="Enter admin code"
                        value={formData.adminCode}
                        onChange={handleInputChange}
                        required
                      />
                      <p className="text-xs text-gray-500">Demo code: ADMIN2024</p>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        placeholder="Doe"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john.doe@example.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {error && <div className="text-red-600 text-sm text-center">{error}</div>}

                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
                    {isLoading ? "Creating Account..." : "Sign Up"}
                  </Button>
                </form>

                <Separator className="my-4" />

                <div className="text-center text-sm text-gray-600">
                  Already have an account?{" "}
                  <Link href="/auth/signin" className="text-blue-600 hover:underline">
                    Sign In
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
