"use client"

import type React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, GraduationCap, LogOut, User, Home, Briefcase, FileText } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuthStore } from "@/lib/auth-store"
import { UnifiedAuthGuard } from "@/components/unified-auth-guard"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: Home },
  { name: "Scholarships", href: "/dashboard/scholarships", icon: GraduationCap },
  { name: "Work-Study", href: "/dashboard/work-study", icon: Briefcase }, // Added Work-Study
  { name: "Applications", href: "/dashboard/applications", icon: FileText }, // Changed icon from Bell to FileText
  { name: "Notifications", href: "/dashboard/notifications", icon: Bell },
]

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { currentUser, logout, notifications } = useAuthStore()
  const router = useRouter()
  const unreadCount = notifications.filter((n) => !n.read).length

  const handleLogout = () => {
    logout()
    router.push("/") // Changed from "/signin" to "/"
  }

  return (
    <UnifiedAuthGuard requiredRole="user">
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <Link href="/dashboard" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
                <GraduationCap className="h-8 w-8 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">Student Financial Assistance</span>
              </Link>

              {/* Desktop Navigation */}
              <nav className="hidden md:flex items-center space-x-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </Link>
                ))}
              </nav>

              <div className="flex items-center space-x-4">
                {/* Profile dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="relative h-10 w-10 rounded-full border-2 border-blue-200 hover:border-blue-400"
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={currentUser?.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-blue-100 text-blue-600 font-semibold">
                          {currentUser?.firstName?.[0]}
                          {currentUser?.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      {unreadCount > 0 && (
                        <Badge
                          variant="destructive"
                          className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs p-0"
                        >
                          {unreadCount}
                        </Badge>
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">
                          {currentUser?.firstName} {currentUser?.lastName}
                        </p>
                        <p className="text-xs leading-none text-muted-foreground">{currentUser?.email}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">
                        <Home className="mr-2 h-4 w-4" />
                        <span>Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard/manage-account">
                        <User className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard/notifications">
                        <Bell className="mr-2 h-4 w-4" />
                        <span>Notifications</span>
                        {unreadCount > 0 && (
                          <Badge variant="secondary" className="ml-auto">
                            {unreadCount}
                          </Badge>
                        )}
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">{children}</div>

            {/* Announcements Panel */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Announcements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">New Scholarship Available</h4>
                    <p className="text-sm text-blue-700 mt-1">Merit-based scholarship for Computer Science students</p>
                    <div className="mt-2 text-xs text-blue-600">
                      <p>
                        <strong>Application Period:</strong> Jan 1 - Mar 31, 2024
                      </p>
                      <p>
                        <strong>Eligibility:</strong> GPA 3.5+ required
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900">Application Reminder</h4>
                    <p className="text-sm text-green-700 mt-1">Don't forget to submit your documents</p>
                    <div className="mt-2 text-xs text-green-600">
                      <p>
                        <strong>Deadline:</strong> February 15, 2024
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </UnifiedAuthGuard>
  )
}
