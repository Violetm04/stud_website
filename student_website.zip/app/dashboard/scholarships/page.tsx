"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Eye, Users, Home, ArrowLeft } from "lucide-react"
import { useAppStore } from "@/lib/store"
import Link from "next/link"

export default function ScholarshipsPage() {
  const { scholarships } = useAppStore()

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/dashboard" className="hover:text-blue-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Scholarship Programs</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Scholarship Programs</h1>
        <p className="text-gray-600 mt-2">Discover scholarships that match your profile</p>
      </div>

      <div className="grid gap-6">
        {scholarships.map((scholarship) => (
          <Card key={scholarship.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{scholarship.name}</CardTitle>
                  <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{scholarship.eligibility}</span>
                    </div>
                  </div>
                </div>
                <Badge variant="secondary">{scholarship.amount}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">Type</p>
                  <p className="text-sm">{scholarship.type}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Deadline</p>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4 text-red-500" />
                    <p className="text-sm">{scholarship.deadline}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Published</p>
                  <p className="text-sm">{scholarship.publishedDate}</p>
                </div>
              </div>

              <div className="flex space-x-3">
                <Button asChild variant="outline" size="sm">
                  <Link href={`/dashboard/scholarships/${scholarship.id}`}>
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Link>
                </Button>
                <Button asChild size="sm">
                  <Link href={`/dashboard/apply/${scholarship.id}`}>Apply Now</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
