"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Home, ArrowLeft } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useSearchParams } from "next/navigation"
import Link from "next/link"

function getStatusBadge(status: string) {
  switch (status) {
    case "approved":
      return <Badge className="bg-green-100 text-green-800">Approved</Badge>
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>
    case "under-review":
      return <Badge variant="secondary">Under Review</Badge>
    case "pending":
      return <Badge variant="outline">Pending</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export default function ApplicationHistory() {
  const { applications } = useAppStore()
  const searchParams = useSearchParams()
  const [showSuccess, setShowSuccess] = useState(false)

  useEffect(() => {
    if (searchParams.get("success") === "true") {
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 5000)
    }
  }, [searchParams])

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/dashboard" className="hover:text-blue-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Application History</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Application History</h1>
        <p className="text-gray-600 mt-2">Track the status of your scholarship applications</p>
      </div>

      {showSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex">
            <div className="ml-3">
              <h3 className="text-sm font-medium text-green-800">Application Submitted Successfully!</h3>
              <div className="mt-2 text-sm text-green-700">
                <p>Your scholarship application has been submitted and is now under review.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Your Applications</CardTitle>
        </CardHeader>
        <CardContent>
          {applications.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No applications submitted yet.</p>
              <p className="text-sm text-gray-400 mt-1">Start by browsing available scholarships.</p>
              <Button asChild className="mt-4">
                <Link href="/dashboard/scholarships">Browse Scholarships</Link>
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application ID</TableHead>
                  <TableHead>Scholarship</TableHead>
                  <TableHead>School</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Year Level</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date Applied</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell className="font-medium">{application.id}</TableCell>
                    <TableCell>{application.scholarshipName}</TableCell>
                    <TableCell>{application.school}</TableCell>
                    <TableCell>{application.course}</TableCell>
                    <TableCell className="capitalize">{application.yearLevel}</TableCell>
                    <TableCell>{getStatusBadge(application.status)}</TableCell>
                    <TableCell>{application.dateApplied}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
