"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, CheckCircle, Clock, AlertCircle, Home, ArrowLeft } from "lucide-react"
import { useAppStore } from "@/lib/store"
import Link from "next/link"

function getNotificationIcon(type: string) {
  switch (type) {
    case "success":
      return <CheckCircle className="h-5 w-5 text-green-600" />
    case "warning":
      return <Clock className="h-5 w-5 text-orange-600" />
    case "error":
      return <AlertCircle className="h-5 w-5 text-red-600" />
    default:
      return <Bell className="h-5 w-5 text-blue-600" />
  }
}

export default function Notifications() {
  const { notifications, markNotificationAsRead } = useAppStore()

  const handleMarkAsRead = (id: string) => {
    markNotificationAsRead(id)
  }

  const handleMarkAllAsRead = () => {
    notifications.forEach((notification) => {
      if (!notification.read) {
        markNotificationAsRead(notification.id)
      }
    })
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/dashboard" className="hover:text-blue-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Notifications</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
          <p className="text-gray-600 mt-2">Stay updated with your scholarship applications</p>
        </div>
        {unreadCount > 0 && (
          <Button onClick={handleMarkAllAsRead} variant="outline">
            Mark All as Read ({unreadCount})
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {notifications.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No notifications yet.</p>
            <p className="text-sm text-gray-400 mt-1">You'll see updates about your applications here.</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`${!notification.read ? "border-blue-200 bg-blue-50" : ""} cursor-pointer hover:shadow-md transition-shadow`}
              onClick={() => !notification.read && handleMarkAsRead(notification.id)}
            >
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  {getNotificationIcon(notification.type)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                      <div className="flex items-center space-x-2">
                        {!notification.read && <Badge variant="secondary">New</Badge>}
                        <span className="text-sm text-gray-500">{notification.time}</span>
                      </div>
                    </div>
                    <p className="text-gray-600 mt-1">{notification.message}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
