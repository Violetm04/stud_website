"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Calendar, FileText, TrendingUp } from "lucide-react"
// Import the new auth store
import { useAuthStore } from "@/lib/auth-store"
import Link from "next/link"

export default function Dashboard() {
  const { applications, scholarships, notifications } = useAuthStore()

  // Rest of the component remains the same
  const activeApplications = applications.filter(
    (app) => app.status === "pending" || app.status === "under-review",
  ).length

  const upcomingDeadlines = scholarships.filter((scholarship) => {
    const deadline = new Date(scholarship.deadline)
    const now = new Date()
    const diffTime = deadline.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays <= 7 && diffDays > 0
  })

  const successRate =
    applications.length > 0
      ? Math.round((applications.filter((app) => app.status === "approved").length / applications.length) * 100)
      : 0

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Welcome back! Here's your scholarship overview.</p>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Applications</p>
                <p className="text-2xl font-bold">{activeApplications}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Available Scholarships</p>
                <p className="text-2xl font-bold">{scholarships.length}</p>
              </div>
              <BookOpen className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Upcoming Deadlines</p>
                <p className="text-2xl font-bold">{upcomingDeadlines.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold">{successRate}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Navigation Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-blue-600" />
              <span>Scholarship Programs</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Browse and apply for available scholarships</p>
            <Button asChild className="w-full">
              <Link href="/dashboard/scholarships">View Programs</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-green-600" />
              <span>Application History</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Track your scholarship applications</p>
            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/dashboard/applications">View History</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-orange-600" />
              <span>Upcoming Deadlines</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 mb-4">
              {upcomingDeadlines.slice(0, 2).map((scholarship) => {
                const deadline = new Date(scholarship.deadline)
                const now = new Date()
                const diffTime = deadline.getTime() - now.getTime()
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

                return (
                  <div key={scholarship.id} className="flex justify-between items-center">
                    <span className="text-sm truncate">{scholarship.name}</span>
                    <Badge variant={diffDays <= 3 ? "destructive" : "secondary"}>
                      {diffDays} day{diffDays !== 1 ? "s" : ""}
                    </Badge>
                  </div>
                )
              })}
              {upcomingDeadlines.length === 0 && <p className="text-sm text-gray-500">No upcoming deadlines</p>}
            </div>
            <Button variant="outline" className="w-full bg-transparent" asChild>
              <Link href="/dashboard/scholarships">View All</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
