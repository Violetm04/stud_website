"use client"

import Link from "next/link"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAppStore } from "@/lib/store"
import { ArrowLeft } from "lucide-react"

export default function ScholarshipApplication({ params }: { params: { id: string } }) {
  const { getScholarship, submitApplication, user } = useAppStore()
  const router = useRouter()
  const scholarship = getScholarship(params.id)

  const [formData, setFormData] = useState({
    fullName: user?.firstName + " " + user?.lastName || "",
    surname: user?.lastName || "",
    dateOfBirth: user?.dateOfBirth || "",
    address: user?.address || "",
    email: user?.email || "",
    phone: user?.phone || "",
    studentId: user?.studentId || "",
    school: user?.school || "",
    course: user?.course || "",
    yearLevel: user?.yearLevel || "",
    submissionInstructions: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      yearLevel: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!scholarship || !user) return

    setIsSubmitting(true)

    try {
      submitApplication({
        scholarshipId: scholarship.id,
        scholarshipName: scholarship.name,
        userId: user.id,
        ...formData,
      })

      // Redirect to applications page with success message
      router.push("/dashboard/applications?success=true")
    } catch (error) {
      console.error("Application submission failed:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!scholarship) {
    return (
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Scholarship Not Found</h1>
          <Button asChild className="mt-4">
            <Link href="/dashboard/scholarships">Back to Scholarships</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard/scholarships">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Scholarships
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Scholarship Application</h1>
        <p className="text-gray-600 mt-2">{scholarship.name}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Application Form</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="surname">Surname</Label>
                <Input
                  id="surname"
                  placeholder="Enter your surname"
                  value={formData.surname}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                placeholder="Enter your full address"
                value={formData.address}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  placeholder="+1 (555) 123-4567"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="studentId">Student ID</Label>
                <Input
                  id="studentId"
                  placeholder="Enter your student ID"
                  value={formData.studentId}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="school">Current School or University</Label>
              <Input
                id="school"
                placeholder="Enter your institution name"
                value={formData.school}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="course">Course or Program Enrolled</Label>
                <Input
                  id="course"
                  placeholder="e.g., Computer Science"
                  value={formData.course}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="yearLevel">Year Level</Label>
                <Select value={formData.yearLevel} onValueChange={handleSelectChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="freshman">Freshman (1st Year)</SelectItem>
                    <SelectItem value="sophomore">Sophomore (2nd Year)</SelectItem>
                    <SelectItem value="junior">Junior (3rd Year)</SelectItem>
                    <SelectItem value="senior">Senior (4th Year)</SelectItem>
                    <SelectItem value="graduate">Graduate Student</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="submissionInstructions">Submission Instructions</Label>
              <Textarea
                id="submissionInstructions"
                placeholder="Please provide any additional information or explain why you deserve this scholarship..."
                className="min-h-[120px]"
                value={formData.submissionInstructions}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="flex space-x-4 pt-6">
              <Button type="submit" size="lg" disabled={isSubmitting}>
                {isSubmitting ? "Submitting Application..." : "Submit Application"}
              </Button>
              <Button variant="outline" size="lg" type="button" onClick={() => router.back()}>
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
