"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Briefcase, Calendar, DollarSign, Home, ArrowLeft } from "lucide-react"
import { useAuthStore } from "@/lib/auth-store" // Corrected import
import Link from "next/link"
import type { WorkStudyProgram, WorkStudyApplication } from "@/lib/types"

export default function WorkStudyPage() {
  const { getWorkStudyPrograms, getWorkStudyApplications, currentUser, applyForWorkStudy } = useAuthStore() // Corrected user to currentUser
  const availablePrograms = getWorkStudyPrograms()
  const myApplications = getWorkStudyApplications().filter((app) => app.userId === currentUser?.id) // Corrected user to currentUser
  const [isApplying, setIsApplying] = useState(false)

  const handleApply = async (program: WorkStudyProgram) => {
    if (!currentUser) {
      // Corrected user to currentUser
      alert("Please sign in to apply for work-study programs.")
      return
    }
    setIsApplying(true)
    try {
      await applyForWorkStudy({
        programId: program.id,
        programTitle: program.title,
        userId: currentUser.id, // Corrected user to currentUser
        fullName: `${currentUser.firstName} ${currentUser.lastName}`, // Corrected user to currentUser
        studentId: currentUser.studentId || "N/A", // Corrected user to currentUser
      })
      alert(`Successfully applied for ${program.title}!`)
    } catch (error) {
      console.error("Failed to apply:", error)
      alert("Failed to submit application. Please try again.")
    } finally {
      setIsApplying(false)
    }
  }

  const getApplicationStatusBadge = (status: WorkStudyApplication["status"]) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      case "pending":
        return <Badge variant="outline">Pending</Badge>
      case "completed":
        return <Badge variant="secondary">Completed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/dashboard" className="hover:text-blue-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Work-Study Programs</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Work-Study Programs</h1>
        <p className="text-gray-600 mt-2">Earn tuition credits or income through on-campus jobs</p>
      </div>

      {/* Available Programs */}
      <Card>
        <CardHeader>
          <CardTitle>Available Programs</CardTitle>
        </CardHeader>
        <CardContent>
          {availablePrograms.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No work-study programs available at the moment.</p>
            </div>
          ) : (
            <div className="grid gap-6">
              {availablePrograms.map((program) => (
                <Card key={program.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl">{program.title}</CardTitle>
                        <p className="text-gray-600 mt-1">{program.department}</p>
                      </div>
                      <Badge variant="secondary">{program.payRate}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4 line-clamp-2">{program.description}</p>
                    <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600 mb-4">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>Deadline: {program.applicationDeadline}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Briefcase className="h-4 w-4" />
                        <span>{program.hoursPerWeek} hrs/week</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <DollarSign className="h-4 w-4" />
                        <span>{program.slotsAvailable} slots left</span>
                      </div>
                    </div>
                    <Button onClick={() => handleApply(program)} disabled={isApplying}>
                      {isApplying ? "Applying..." : "Apply Now"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* My Applications */}
      <Card>
        <CardHeader>
          <CardTitle>My Work-Study Applications</CardTitle>
        </CardHeader>
        <CardContent>
          {myApplications.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">You haven't applied for any work-study programs yet.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Program Title</TableHead>
                  <TableHead>Date Applied</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myApplications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">{app.programTitle}</TableCell>
                    <TableCell>{app.dateApplied}</TableCell>
                    <TableCell>{getApplicationStatusBadge(app.status)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
