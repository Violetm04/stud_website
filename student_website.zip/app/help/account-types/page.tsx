"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BackButton } from "@/components/navigation/back-button"
import { User, Shield, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function AccountTypesHelp() {
  const studentFeatures = [
    "Browse scholarship programs",
    "Submit applications",
    "Track application status",
    "Receive notifications",
    "Manage personal profile",
    "View application history",
  ]

  const adminFeatures = [
    "Create and manage scholarships",
    "Review applications",
    "Approve/reject applications",
    "Create announcements",
    "View all user data",
    "System administration",
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <BackButton fallbackUrl="/" label="Back to Home" />
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Account Types</h1>
          <p className="text-xl text-gray-600">Choose the right account type for your needs</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Student Account */}
          <Card className="border-2 border-blue-200">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 p-3 bg-blue-100 rounded-full w-fit">
                <User className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle className="text-2xl">Student Account</CardTitle>
              <Badge variant="secondary" className="w-fit mx-auto">
                Most Common
              </Badge>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-3">What you can do:</h3>
                <ul className="space-y-2">
                  {studentFeatures.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">How to create:</h4>
                <p className="text-sm text-blue-800 mb-3">
                  Simply use any email address and password. No special codes required!
                </p>
                <Button asChild className="w-full">
                  <Link href="/auth/signup">Create Student Account</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Admin Account */}
          <Card className="border-2 border-purple-200">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 p-3 bg-purple-100 rounded-full w-fit">
                <Shield className="h-8 w-8 text-purple-600" />
              </div>
              <CardTitle className="text-2xl">Admin Account</CardTitle>
              <Badge variant="outline" className="w-fit mx-auto">
                Restricted
              </Badge>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-3">What you can do:</h3>
                <ul className="space-y-2">
                  {adminFeatures.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">How to create:</h4>
                <p className="text-sm text-purple-800 mb-2">Requires a special admin code for security.</p>
                <div className="bg-white p-2 rounded border mb-3">
                  <p className="text-xs text-gray-600">Demo Admin Code:</p>
                  <code className="font-mono text-sm font-bold">ADMIN2024</code>
                </div>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/auth/admin-signup">Create Admin Account</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Demo Credentials */}
        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-center text-yellow-800">Demo Credentials</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-yellow-900 mb-2">Test Admin Account:</h4>
                <div className="bg-white p-3 rounded border">
                  <p className="text-sm">
                    <strong>Email:</strong> admin@scholarhub.com
                  </p>
                  <p className="text-sm">
                    <strong>Password:</strong> admin123
                  </p>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-yellow-900 mb-2">Test Student Account:</h4>
                <div className="bg-white p-3 rounded border">
                  <p className="text-sm">
                    <strong>Email:</strong> Any email
                  </p>
                  <p className="text-sm">
                    <strong>Password:</strong> Any password
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-8">
          <Button asChild variant="outline">
            <Link href="/auth/signin">Go to Sign In</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
