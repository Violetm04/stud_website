import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardTitle } from "@/components/ui/card"
import { ArrowLeft, GraduationCap, Briefcase, DollarSign, Lightbulb } from "lucide-react"

export default function LearnMorePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Home</span>
          </Link>
          <div className="flex items-center space-x-2">
            <GraduationCap className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">Student Financial Assistance</span>
          </div>
        </div>

        <h1 className="text-4xl font-extrabold text-gray-900 text-center mb-10">Learn More About Our System</h1>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <GraduationCap className="h-12 w-12 text-blue-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Scholarship Opportunities</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Discover a wide range of scholarships tailored to your academic achievements, interests, and financial
              needs. Our platform simplifies the application process.
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <Briefcase className="h-12 w-12 text-green-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Work-Study Programs</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Gain valuable work experience and earn income or tuition credits through flexible on-campus work-study
              programs.
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <DollarSign className="h-12 w-12 text-purple-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Alternative Payment Solutions</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Explore innovative ways to manage your tuition and fees, including micro-loans and flexible installment
              plans designed for students.
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <Lightbulb className="h-12 w-12 text-yellow-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Financial Literacy Resources</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Access a curated collection of articles, workshops, and tools to help you make informed financial
              decisions and manage your money effectively.
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <Lightbulb className="h-12 w-12 text-red-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Crowdfunding for Education</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Launch and manage your own crowdfunding campaigns to raise funds for your educational expenses with
              support from your community.
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center text-center p-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <Lightbulb className="h-12 w-12 text-indigo-600 mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Dedicated Support</CardTitle>
            <CardContent className="text-gray-700 text-sm">
              Our support team is here to assist you with any questions regarding applications, programs, or system
              usage.
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Get Started?</h2>
          <p className="text-lg text-gray-700 mb-6">
            Join our platform today and take the first step towards securing your financial future in education.
          </p>
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/auth/signup">Sign Up Now</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
