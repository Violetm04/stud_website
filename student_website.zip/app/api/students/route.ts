import { sql } from "@/lib/db" // Import our database client
import { NextResponse } from "next/server" // For sending JSON responses

export async function GET() {
  try {
    // Use the 'sql' client to execute a SQL query to select all students.
    const students = await sql`SELECT * FROM students;`
    // Return the students data as a JSON response.
    return NextResponse.json(students)
  } catch (error) {
    console.error("Error fetching students:", error)
    // If there's an error, return a 500 status code and an error message.
    return NextResponse.json({ error: "Failed to fetch students" }, { status: 500 })
  }
}
