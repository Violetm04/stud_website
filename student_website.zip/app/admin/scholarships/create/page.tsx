"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, X } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import { BackButton } from "@/components/navigation/back-button"

export default function CreateScholarship() {
  const { createScholarship } = useAdminStore()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const [formData, setFormData] = useState({
    name: "",
    type: "",
    eligibility: "",
    academicYear: "",
    description: "",
    deadline: "",
    publishedDate: new Date().toISOString().split("T")[0],
    amount: "",
  })

  const [criteria, setCriteria] = useState<string[]>([""])
  const [documents, setDocuments] = useState<string[]>([""])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.id]: e.target.value,
    }))
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const addCriterion = () => {
    setCriteria([...criteria, ""])
  }

  const updateCriterion = (index: number, value: string) => {
    const newCriteria = [...criteria]
    newCriteria[index] = value
    setCriteria(newCriteria)
  }

  const removeCriterion = (index: number) => {
    setCriteria(criteria.filter((_, i) => i !== index))
  }

  const addDocument = () => {
    setDocuments([...documents, ""])
  }

  const updateDocument = (index: number, value: string) => {
    const newDocuments = [...documents]
    newDocuments[index] = value
    setDocuments(newDocuments)
  }

  const removeDocument = (index: number) => {
    setDocuments(documents.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const scholarshipData = {
        ...formData,
        criteria: criteria.filter((c) => c.trim() !== ""),
        documents: documents.filter((d) => d.trim() !== ""),
      }

      createScholarship(scholarshipData)
      router.push("/admin/scholarships")
    } catch (error) {
      console.error("Failed to create scholarship:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-4">
        <BackButton fallbackUrl="/admin/scholarships" />
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Add Scholarship</h1>
        <p className="text-gray-600 mt-2">Create a new scholarship program</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Scholarship Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Scholarship Name</Label>
                <Input
                  id="name"
                  placeholder="Enter scholarship name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Scholarship Type</Label>
                <Select value={formData.type} onValueChange={(value) => handleSelectChange("type", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Merit-based">Merit-based</SelectItem>
                    <SelectItem value="Need-based">Need-based</SelectItem>
                    <SelectItem value="Field-specific">Field-specific</SelectItem>
                    <SelectItem value="Leadership">Leadership</SelectItem>
                    <SelectItem value="Community Service">Community Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="eligibility">Student Eligibility</Label>
                <Input
                  id="eligibility"
                  placeholder="e.g., Undergraduate students with GPA 3.5+"
                  value={formData.eligibility}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="academicYear">Academic Year</Label>
                <Input
                  id="academicYear"
                  placeholder="e.g., 2024-2025"
                  value={formData.academicYear}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Scholarship Description</Label>
              <Textarea
                id="description"
                placeholder="Enter detailed description of the scholarship"
                className="min-h-[120px]"
                value={formData.description}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="deadline">Application Deadline</Label>
                <Input
                  id="deadline"
                  placeholder="e.g., March 15, 2024"
                  value={formData.deadline}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="publishedDate">Published Date</Label>
                <Input
                  id="publishedDate"
                  type="date"
                  value={formData.publishedDate}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Scholarship Amount</Label>
                <Input
                  id="amount"
                  placeholder="e.g., $5,000"
                  value={formData.amount}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            {/* Eligibility Criteria */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Eligibility Criteria</Label>
                <Button type="button" variant="outline" size="sm" onClick={addCriterion}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Criterion
                </Button>
              </div>
              {criteria.map((criterion, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Input
                    placeholder="Enter eligibility criterion"
                    value={criterion}
                    onChange={(e) => updateCriterion(index, e.target.value)}
                  />
                  {criteria.length > 1 && (
                    <Button type="button" variant="outline" size="sm" onClick={() => removeCriterion(index)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {/* Document Requirements */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Document Requirements</Label>
                <Button type="button" variant="outline" size="sm" onClick={addDocument}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Document
                </Button>
              </div>
              {documents.map((document, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Input
                    placeholder="Enter required document"
                    value={document}
                    onChange={(e) => updateDocument(index, e.target.value)}
                  />
                  {documents.length > 1 && (
                    <Button type="button" variant="outline" size="sm" onClick={() => removeDocument(index)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex space-x-4 pt-6">
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Creating..." : "Create Scholarship"}
              </Button>
              <Button type="button" variant="outline" onClick={() => router.back()}>
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
