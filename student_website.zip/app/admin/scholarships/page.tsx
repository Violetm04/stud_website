"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Eye, Edit, Trash2, Plus, Home, ArrowLeft } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import { DeleteConfirmModal } from "@/components/admin/delete-confirm-modal"
import Link from "next/link"
import type { Scholarship } from "@/lib/types"

export default function AdminScholarships() {
  const { scholarships, deleteScholarship } = useAdminStore()
  const [deletingScholarship, setDeletingScholarship] = useState<Scholarship | null>(null)

  const handleDelete = (scholarship: Scholarship) => {
    setDeletingScholarship(scholarship)
  }

  const confirmDelete = () => {
    if (deletingScholarship) {
      deleteScholarship(deletingScholarship.id)
      setDeletingScholarship(null)
    }
  }

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/admin/dashboard" className="hover:text-purple-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Scholarship Programs</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scholarship Programs</h1>
          <p className="text-gray-600 mt-2">Manage scholarship programs and applications</p>
        </div>
        <Button asChild>
          <Link href="/admin/scholarships/create">
            <Plus className="h-4 w-4 mr-2" />
            Add Scholarship
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Scholarships</CardTitle>
        </CardHeader>
        <CardContent>
          {scholarships.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No scholarships yet.</p>
              <Button asChild className="mt-4">
                <Link href="/admin/scholarships/create">Create First Scholarship</Link>
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Scholarship Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Student Eligibility</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Published Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scholarships.map((scholarship) => (
                  <TableRow key={scholarship.id}>
                    <TableCell className="font-medium">{scholarship.name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{scholarship.type}</Badge>
                    </TableCell>
                    <TableCell>{scholarship.eligibility}</TableCell>
                    <TableCell>{scholarship.deadline}</TableCell>
                    <TableCell>{scholarship.publishedDate}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/scholarships/${scholarship.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/scholarships/${scholarship.id}/edit`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(scholarship)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <DeleteConfirmModal
        isOpen={!!deletingScholarship}
        onClose={() => setDeletingScholarship(null)}
        onConfirm={confirmDelete}
        title="Delete Scholarship"
        message="Are you sure you want to delete this scholarship? This action cannot be undone."
      />
    </div>
  )
}
