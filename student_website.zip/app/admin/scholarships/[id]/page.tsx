"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, FileText, Users } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { BackButton } from "@/components/navigation/back-button"

export default function AdminScholarshipDetails({ params }: { params: { id: string } }) {
  const { getScholarship } = useAdminStore()
  const router = useRouter()
  const scholarship = getScholarship(params.id)

  if (!scholarship) {
    return (
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Scholarship Not Found</h1>
          <p className="text-gray-600 mt-2">The scholarship you're looking for doesn't exist.</p>
          <Button asChild className="mt-4">
            <Link href="/admin/scholarships">Back to Scholarships</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <BackButton fallbackUrl="/admin/scholarships" />
        <Button asChild>
          <Link href="/admin/scholarships/create">Add Scholarship</Link>
        </Button>
      </div>

      <div>
        <div className="flex justify-between items-start mb-4">
          <h1 className="text-3xl font-bold text-gray-900">{scholarship.name}</h1>
          <Badge variant="secondary" className="text-lg px-3 py-1">
            {scholarship.amount}
          </Badge>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium text-gray-600">Scholarship Type</p>
              <p className="text-sm">{scholarship.type}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-sm font-medium text-gray-600">Student Eligibility</p>
              <p className="text-sm">{scholarship.eligibility}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-red-600" />
            <div>
              <p className="text-sm font-medium text-gray-600">Application Deadline</p>
              <p className="text-sm font-semibold">{scholarship.deadline}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Academic Year</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{scholarship.academicYear}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Eligibility Criteria</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {scholarship.criteria.map((criterion, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <span className="text-green-600 mt-1">•</span>
                    <span className="text-sm">{criterion}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Scholarship Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{scholarship.description}</p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {scholarship.documents.map((document, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <FileText className="h-4 w-4 text-blue-600 mt-1" />
                    <span className="text-sm">{document}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Important Dates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Application Deadline:</span>
                  <span className="text-sm text-red-600 font-semibold">{scholarship.deadline}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Academic Year:</span>
                  <span className="text-sm">{scholarship.academicYear}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
