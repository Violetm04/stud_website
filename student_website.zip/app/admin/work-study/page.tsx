"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Eye, Edit, Trash2, Home, ArrowLeft, Check, X } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import { DeleteConfirmModal } from "@/components/admin/delete-confirm-modal"
import { WorkStudyProgramModal } from "@/components/work-study/work-study-program-modal"
import { WorkStudyApplicationModal } from "@/components/work-study/work-study-application-modal"
import Link from "next/link"
import type { WorkStudyProgram, WorkStudyApplication } from "@/lib/types"

export default function AdminWorkStudy() {
  const { getWorkStudyPrograms, deleteWorkStudyProgram, getWorkStudyApplications, updateWorkStudyApplicationStatus } =
    useAdminStore()
  const programs = getWorkStudyPrograms()
  const applications = getWorkStudyApplications()

  const [deletingProgram, setDeletingProgram] = useState<WorkStudyProgram | null>(null)
  const [isProgramModalOpen, setIsProgramModalOpen] = useState(false)
  const [editingProgram, setEditingProgram] = useState<WorkStudyProgram | null>(null)

  const [isApplicationModalOpen, setIsApplicationModalOpen] = useState(false)
  const [viewingApplication, setViewingApplication] = useState<WorkStudyApplication | null>(null)

  const handleCreateProgram = () => {
    setEditingProgram(null)
    setIsProgramModalOpen(true)
  }

  const handleEditProgram = (program: WorkStudyProgram) => {
    setEditingProgram(program)
    setIsProgramModalOpen(true)
  }

  const handleDeleteProgram = (program: WorkStudyProgram) => {
    setDeletingProgram(program)
  }

  const confirmDeleteProgram = () => {
    if (deletingProgram) {
      deleteWorkStudyProgram(deletingProgram.id)
      setDeletingProgram(null)
    }
  }

  const handleViewApplication = (application: WorkStudyApplication) => {
    setViewingApplication(application)
    setIsApplicationModalOpen(true)
  }

  const getApplicationStatusBadge = (status: WorkStudyApplication["status"]) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      case "pending":
        return <Badge variant="outline">Pending</Badge>
      case "completed":
        return <Badge variant="secondary">Completed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/admin/dashboard" className="hover:text-purple-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Work-Study Management</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Work-Study Management</h1>
          <p className="text-gray-600 mt-2">Manage work-study programs and student applications</p>
        </div>
        <Button onClick={handleCreateProgram}>
          <Plus className="h-4 w-4 mr-2" />
          Add New Program
        </Button>
      </div>

      {/* Work-Study Programs */}
      <Card>
        <CardHeader>
          <CardTitle>Work-Study Programs</CardTitle>
        </CardHeader>
        <CardContent>
          {programs.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No work-study programs created yet.</p>
              <Button onClick={handleCreateProgram} className="mt-4">
                Create First Program
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Hours/Week</TableHead>
                  <TableHead>Pay Rate</TableHead>
                  <TableHead>Slots</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {programs.map((program) => (
                  <TableRow key={program.id}>
                    <TableCell className="font-medium">{program.title}</TableCell>
                    <TableCell>{program.department}</TableCell>
                    <TableCell>{program.hoursPerWeek}</TableCell>
                    <TableCell>{program.payRate}</TableCell>
                    <TableCell>{program.slotsAvailable}</TableCell>
                    <TableCell>{program.applicationDeadline}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditProgram(program)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteProgram(program)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Work-Study Applications */}
      <Card>
        <CardHeader>
          <CardTitle>Work-Study Applications</CardTitle>
        </CardHeader>
        <CardContent>
          {applications.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No work-study applications received yet.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Program</TableHead>
                  <TableHead>Applicant</TableHead>
                  <TableHead>Student ID</TableHead>
                  <TableHead>Date Applied</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">{app.programTitle}</TableCell>
                    <TableCell>{app.fullName}</TableCell>
                    <TableCell>{app.studentId}</TableCell>
                    <TableCell>{app.dateApplied}</TableCell>
                    <TableCell>{getApplicationStatusBadge(app.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleViewApplication(app)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        {app.status !== "approved" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateWorkStudyApplicationStatus(app.id, "approved")}
                            className="text-green-600 hover:text-green-700"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        {app.status !== "rejected" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateWorkStudyApplicationStatus(app.id, "rejected")}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      <WorkStudyProgramModal
        isOpen={isProgramModalOpen}
        onClose={() => setIsProgramModalOpen(false)}
        program={editingProgram}
        mode={editingProgram ? "edit" : "create"}
      />

      <WorkStudyApplicationModal
        isOpen={isApplicationModalOpen}
        onClose={() => setIsApplicationModalOpen(false)}
        application={viewingApplication}
      />

      <DeleteConfirmModal
        isOpen={!!deletingProgram}
        onClose={() => setDeletingProgram(null)}
        onConfirm={confirmDeleteProgram}
        title="Delete Work-Study Program"
        message="Are you sure you want to delete this work-study program? This action cannot be undone."
      />
    </div>
  )
}
