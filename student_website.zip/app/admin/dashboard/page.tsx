"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Edit, Trash2, Plus } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import { AnnouncementModal } from "@/components/admin/announcement-modal"
import { DeleteConfirmModal } from "@/components/admin/delete-confirm-modal"
import type { Announcement } from "@/lib/admin-store"

export default function AdminDashboard() {
  const { announcements, deleteAnnouncement } = useAdminStore()
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null)
  const [deletingAnnouncement, setDeletingAnnouncement] = useState<Announcement | null>(null)

  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement)
  }

  const handleDelete = (announcement: Announcement) => {
    setDeletingAnnouncement(announcement)
  }

  const confirmDelete = () => {
    if (deletingAnnouncement) {
      deleteAnnouncement(deletingAnnouncement.id)
      setDeletingAnnouncement(null)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Overview</h1>
          <p className="text-gray-600 mt-2">Manage announcements and system overview</p>
        </div>
        <Button onClick={() => setIsCreateModalOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Create New Announcement
        </Button>
      </div>

      {/* Announcements */}
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold text-gray-900">Announcements</h2>

        {announcements.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-gray-500">No announcements yet.</p>
              <Button onClick={() => setIsCreateModalOpen(true)} className="mt-4">
                Create First Announcement
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {announcements.map((announcement) => (
              <Card key={announcement.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{announcement.title}</CardTitle>
                      <p className="text-gray-600 mt-2">{announcement.content}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(announcement)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(announcement)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Application Period</p>
                      <p className="text-sm">{announcement.applicationPeriod}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Requirement 1</p>
                      <p className="text-sm">{announcement.requirement1}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Requirement 2</p>
                      <p className="text-sm">{announcement.requirement2}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      <AnnouncementModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        announcement={null}
        mode="create"
      />

      <AnnouncementModal
        isOpen={!!editingAnnouncement}
        onClose={() => setEditingAnnouncement(null)}
        announcement={editingAnnouncement}
        mode="edit"
      />

      <DeleteConfirmModal
        isOpen={!!deletingAnnouncement}
        onClose={() => setDeletingAnnouncement(null)}
        onConfirm={confirmDelete}
        title="Delete Announcement"
        message="Are you sure you want to delete this announcement? This action cannot be undone."
      />
    </div>
  )
}
