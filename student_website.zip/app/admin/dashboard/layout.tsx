"use client"

import type React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, GraduationCap, LogOut, User, Home, FileText, Settings, Shield, Briefcase } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAdminStore } from "@/lib/admin-store"
import { AdminAuthGuard } from "@/components/admin-auth-guard"

const navigation = [
  { name: "Dashboard", href: "/admin/dashboard", icon: Home },
  { name: "Scholarships", href: "/admin/scholarships", icon: GraduationCap },
  { name: "Work-Study", href: "/admin/work-study", icon: Briefcase }, // Added Work-Study
  { name: "Applications", href: "/admin/applications", icon: FileText },
  { name: "Notifications", href: "/admin/notifications", icon: Bell },
  { name: "Settings", href: "/admin/settings", icon: Settings },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { adminUser, adminLogout } = useAdminStore()
  const router = useRouter()

  const handleLogout = () => {
    adminLogout()
    router.push("/") // Changed from "/admin/login" to "/"
  }

  return (
    <AdminAuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <Link href="/admin/dashboard" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
                <Shield className="h-8 w-8 text-purple-600" />
                <span className="text-2xl font-bold text-gray-900">Financial System Admin</span>
              </Link>

              {/* Desktop Navigation */}
              <nav className="hidden md:flex items-center space-x-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="flex items-center space-x-2 text-gray-600 hover:text-purple-600 transition-colors"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </Link>
                ))}
              </nav>

              <div className="flex items-center space-x-4">
                {/* Profile dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="relative h-10 w-10 rounded-full border-2 border-purple-200 hover:border-purple-400"
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={adminUser?.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-purple-100 text-purple-600 font-semibold">
                          {adminUser?.firstName?.[0]}
                          {adminUser?.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">
                          {adminUser?.firstName} {adminUser?.lastName}
                        </p>
                        <p className="text-xs leading-none text-muted-foreground">{adminUser?.email}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard">
                        <Home className="mr-2 h-4 w-4" />
                        <span>Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/admin/profile">
                        <User className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/admin/notifications">
                        <Bell className="mr-2 h-4 w-4" />
                        <span>Notifications</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/admin/settings">
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Settings</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">{children}</div>

            {/* Admin Panel */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">System Status</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900">System Online</h4>
                    <p className="text-sm text-green-700 mt-1">All services running normally</p>
                    <div className="mt-2 text-xs text-green-600">
                      <p>
                        <strong>Uptime:</strong> 99.9%
                      </p>
                      <p>
                        <strong>Last Update:</strong> 2 hours ago
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">Recent Activity</h4>
                    <p className="text-sm text-blue-700 mt-1">5 new applications today</p>
                    <div className="mt-2 text-xs text-blue-600">
                      <p>
                        <strong>Pending Review:</strong> 12 applications
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AdminAuthGuard>
  )
}
