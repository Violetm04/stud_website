"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { User, Mail, Phone, MapPin, GraduationCap, Calendar } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import { useRouter } from "next/navigation"
import { BackButton } from "@/components/navigation/back-button"

function getStatusBadge(status: string) {
  switch (status) {
    case "approved":
      return <Badge className="bg-green-100 text-green-800">Approved</Badge>
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>
    case "under-review":
      return <Badge variant="secondary">Under Review</Badge>
    case "pending":
      return <Badge variant="outline">Pending</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export default function AdminApplicationDetails({ params }: { params: { id: string } }) {
  const { getApplication } = useAdminStore()
  const router = useRouter()
  const application = getApplication(params.id)

  if (!application) {
    return (
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Application Not Found</h1>
          <p className="text-gray-600 mt-2">The application you're looking for doesn't exist.</p>
          <Button onClick={() => router.back()} className="mt-4">
            Back to Applications
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center space-x-4">
        <BackButton fallbackUrl="/admin/applications" />
      </div>

      <div>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Application Details</h1>
            <p className="text-gray-600 mt-2">Application ID: {application.id}</p>
          </div>
          {getStatusBadge(application.status)}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Application Information */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>Personal Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">Full Name</p>
                  <p className="text-sm">{application.fullName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Surname</p>
                  <p className="text-sm">{application.surname}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">Date of Birth</p>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <p className="text-sm">{application.dateOfBirth}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Student ID</p>
                  <p className="text-sm">{application.studentId}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600">Email</p>
                <div className="flex items-center space-x-1">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <p className="text-sm">{application.email}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600">Phone Number</p>
                <div className="flex items-center space-x-1">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <p className="text-sm">{application.phone}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600">Address</p>
                <div className="flex items-start space-x-1">
                  <MapPin className="h-4 w-4 text-gray-400 mt-0.5" />
                  <p className="text-sm">{application.address}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <GraduationCap className="h-5 w-5" />
                <span>Educational Background</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-600">Current School or University</p>
                <p className="text-sm">{application.school}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">Course or Program</p>
                  <p className="text-sm">{application.course}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Year Level</p>
                  <p className="text-sm capitalize">{application.yearLevel}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Application Status and Documents */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Application Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-600">Scholarship</p>
                <p className="text-sm font-semibold">{application.scholarshipName}</p>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600">Current Status</p>
                {getStatusBadge(application.status)}
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600">Date Applied</p>
                <p className="text-sm">{application.dateApplied}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Submission Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700 leading-relaxed">{application.submissionInstructions}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Documents</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">Document upload functionality would be implemented here.</p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">Official Transcripts</span>
                  <Badge variant="outline">Pending</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">Personal Statement</span>
                  <Badge variant="outline">Pending</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">Letters of Recommendation</span>
                  <Badge variant="outline">Pending</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
