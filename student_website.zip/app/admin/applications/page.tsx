"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Eye, Check, X, Home, ArrowLeft } from "lucide-react"
import { useAdminStore } from "@/lib/admin-store"
import Link from "next/link"

function getStatusBadge(status: string) {
  switch (status) {
    case "approved":
      return <Badge className="bg-green-100 text-green-800">Approved</Badge>
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>
    case "under-review":
      return <Badge variant="secondary">Under Review</Badge>
    case "pending":
      return <Badge variant="outline">Pending</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export default function AdminApplications() {
  const { applications, updateApplicationStatus } = useAdminStore()

  const handleApprove = (applicationId: string) => {
    updateApplicationStatus(applicationId, "approved")
  }

  const handleReject = (applicationId: string) => {
    updateApplicationStatus(applicationId, "rejected")
  }

  return (
    <div className="space-y-8">
      {/* Navigation Breadcrumbs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Link href="/admin/dashboard" className="hover:text-purple-600 flex items-center space-x-1">
            <Home className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <span>/</span>
          <span className="text-gray-900 font-medium">Application History</span>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Application History</h1>
        <p className="text-gray-600 mt-2">Review and manage scholarship applications</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Applications</CardTitle>
        </CardHeader>
        <CardContent>
          {applications.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No applications yet.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Full Name</TableHead>
                  <TableHead>Scholarship</TableHead>
                  <TableHead>School</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Year Level</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell className="font-medium">{application.id}</TableCell>
                    <TableCell>{application.fullName}</TableCell>
                    <TableCell>{application.scholarshipName}</TableCell>
                    <TableCell>{application.school}</TableCell>
                    <TableCell>{application.course}</TableCell>
                    <TableCell className="capitalize">{application.yearLevel}</TableCell>
                    <TableCell>{getStatusBadge(application.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/applications/${application.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        {application.status !== "approved" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleApprove(application.id)}
                            className="text-green-600 hover:text-green-700"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        {application.status !== "rejected" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleReject(application.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
