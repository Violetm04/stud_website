"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { BackButton } from "@/components/navigation/back-button"

// Mock admin notifications
const adminNotifications = [
  {
    id: "1",
    type: "info",
    title: "New Application Received",
    message: "John Doe has submitted an application for Merit Excellence Scholarship",
    time: "5 minutes ago",
    read: false,
  },
  {
    id: "2",
    type: "warning",
    title: "Scholarship Deadline Approaching",
    message: "STEM Innovation Grant deadline is in 2 days",
    time: "1 hour ago",
    read: false,
  },
  {
    id: "3",
    type: "success",
    title: "Application Approved",
    message: "You approved Jane Smith's application for Engineering Scholarship",
    time: "2 hours ago",
    read: true,
  },
  {
    id: "4",
    type: "info",
    title: "System Update",
    message: "Scholarship management system has been updated to version 2.1",
    time: "1 day ago",
    read: true,
  },
]

function getNotificationIcon(type: string) {
  switch (type) {
    case "success":
      return <CheckCircle className="h-5 w-5 text-green-600" />
    case "warning":
      return <Clock className="h-5 w-5 text-orange-600" />
    case "error":
      return <AlertCircle className="h-5 w-5 text-red-600" />
    default:
      return <Bell className="h-5 w-5 text-blue-600" />
  }
}

export default function AdminNotifications() {
  const [notifications, setNotifications] = useState(adminNotifications)

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Notifications</h1>
          <p className="text-gray-600 mt-2">Stay updated with system activities and applications</p>
        </div>
        <div className="flex space-x-2">
          {unreadCount > 0 && (
            <Button onClick={handleMarkAllAsRead} variant="outline">
              Mark All as Read ({unreadCount})
            </Button>
          )}
          <BackButton fallbackUrl="/admin/dashboard" label="Back to Dashboard" variant="outline" />
        </div>
      </div>

      <div className="space-y-4">
        {notifications.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No notifications yet.</p>
            <p className="text-sm text-gray-400 mt-1">System notifications will appear here.</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`${!notification.read ? "border-blue-200 bg-blue-50" : ""} cursor-pointer hover:shadow-md transition-shadow`}
              onClick={() => !notification.read && handleMarkAsRead(notification.id)}
            >
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  {getNotificationIcon(notification.type)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                      <div className="flex items-center space-x-2">
                        {!notification.read && <Badge variant="secondary">New</Badge>}
                        <span className="text-sm text-gray-500">{notification.time}</span>
                      </div>
                    </div>
                    <p className="text-gray-600 mt-1">{notification.message}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
