INSERT INTO students (first_name, last_name, email, student_id, school, course, year_level)
VALUES
('John', 'Doe', 'john.doe@example.com', 'STU001', 'State University', 'Computer Science', 'Junior'),
('Jane', 'Smith', 'jane.smith@example.com', 'STU002', 'Tech Institute', 'Engineering', 'Senior'),
('Michael', 'Johnson', 'michael.johnson@example.com', 'STU003', 'Community College', 'Business Administration', 'Sophomore')
ON CONFLICT (email) DO NOTHING;
